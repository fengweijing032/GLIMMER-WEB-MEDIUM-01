package Task1;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Task1_Q2 {
    public static void main(String[] args) {
        // 获取当前项目根目录（glimmer5 所在的目录）
        String projectPath = System.getProperty("user.dir");
        // 用项目根目录拼接出 name.txt 的完整路径
        File source = new File(projectPath + "\\name.txt");

        //存放读取到的名字
        List<String> names = new ArrayList<>();

        //使用try-with-resources创建字符输入流
        //这里是"套娃"写法，从里到外依次是FileInputStream（读字节）、InputStreamReader（翻译为字符）、BufferedReader（缓冲区，多拿点）
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(
                        new FileInputStream(source),
                        StandardCharsets.UTF_8))) { //统一指定UTF-8 编码

            //循环读取，每次读一整行，读到末尾会返回 null（空）
            String line;
            while ((line = br.readLine()) != null) {//把读到的这一行赋值给line，如非空继续
                //先用 trim() 去掉这一行首尾的空格
                line = line.trim();
                //如果去掉空格后发现是空行，就跳过
                if (line.isEmpty()) {
                    continue;
                }
                //打印这一行，看看读到了什么
                System.out.println(line);
                //把名字存进列表
                names.add(line);
            }

        } catch (Exception e) {//出任何意外，就报错
            System.out.println("读取失败：" + e.getMessage());
            return;
        }

        //排序
        Collections.sort(names);

        //写入目标文件name_sorted.txt
        try (BufferedWriter bw = new BufferedWriter(//缓冲流
                new OutputStreamWriter(//字符变字节
                        new FileOutputStream(projectPath + "\\name_sorted.txt"),//指定写入文件
                        StandardCharsets.UTF_8))) {
            for (String name : names) {//遍历名字
                bw.write(name);//写入名字
                bw.newLine();//写完换行，不手敲
            }
            System.out.println("排序并写入成功！共写入 " + names.size() + " 个名字。");
        } catch (Exception e) {
            System.out.println("写入失败：" + e.getMessage());
        }
    }
}