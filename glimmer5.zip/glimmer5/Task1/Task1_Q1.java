package Task1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Task1_Q1 {
    public static void main(String[] args) {
        //指定要复制的源文件（刚才保存的 doro.jpg）
        File source = new File("doro.jpg");
        //指定要生成的目标文件（复制一份，叫 doro_copy.jpg）
        File target = new File("doro_copy.jpg");

        //括号里创建流，用完后会自动关闭，不用手动写 close()
        try (FileInputStream fis = new FileInputStream(source);   // 输入流：从源文件读数据
             FileOutputStream fos = new FileOutputStream(target)) { // 输出流：往目标文件写数据

            //准备一个1024字节大小的盒子（字节数组），一次搬1024个字节，效率高
            byte[] buffer = new byte[1024];
            // len 用来记录每次实际读到了多少个字节
            int len;

            //read(buffer)会把数据读进 buffer 里，返回读到的字节数；读到末尾会返回-1，告诉程序，文件读完了，收工
            while ((len = fis.read(buffer)) != -1) {
                //把buffer里的数据，从下标0开始，写len个字节到目标文件
                fos.write(buffer, 0, len);
            }

            System.out.println("复制成功！");

        } catch (IOException e) {
            //如果出错（比如找不到 doro.jpg），打印错误信息
            System.out.println("复制失败：" + e.getMessage());
        }
    }
}