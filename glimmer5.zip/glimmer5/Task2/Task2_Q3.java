package Task2;

import java.io.*;

public class Task2_Q3 {
    public static void main(String[] args) {
        // 先创建一个 Student 对象，用于序列化
        Student student = new Student(1, "doro", 2, "114514");

        //序列化：把这个对象变成二进制编码存进文件里
        // try-with-resources 会自动关闭流
        try (ObjectOutputStream oos = new ObjectOutputStream(
                new FileOutputStream("student.dat"))) { // 目标文件叫 student.dat
            oos.writeObject(student); // 把 student 对象写进文件write
            System.out.println("序列化成功！student 对象已存进 student.dat");
        } catch (IOException e) {
            System.out.println("序列化失败：" + e.getMessage());
        }

        //反序列化：从文件里把对象读出来，赋值给新的 Student 对象 doro
        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream("student.dat"))) { // 读取刚才生成的文件read
            Student doro = (Student) ois.readObject(); // 读出来的东西是 Object，要强制转成 Student
            System.out.println("反序列化成功！读出来的对象是：");
            System.out.println(doro); // 打印 doro，看看里面的信息对不对
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("反序列化失败：" + e.getMessage());
        }
    }
}