package Task2;

public class Person {
    // 1.为字段和方法补上访问修饰符
    private String name;
    private int age;
    private int sex;



    // 4.增加一个静态变量：用来统计总共创建了多少个 Person 对象
    // static 表示这个变量是属于类的，所有对象共用的，而不属于某个具体的对象
    public static int count = 0;

    // 每次加一个对象，count就加1
    public Person(String name, int age, int sex) {
        this.name = name;
        this.age = age;
        this.sex = sex;
        count++; // 每次创建对象，就让 count 自动加 1
    }

    // 复制构造方法
    public Person(Person other) {
        this.name = other.name;
        this.age = other.age;
        this.sex = other.sex;
        count++; // 复制对象时，也算创建了一个新对象
    }

    // public 表示任何人可以通过这个方法查看信息
    public String getInfo() {
        return "姓名：" + name + "，年龄：" + age + "，性别：" + sex;
    }

    // 5.增加一个静态方法，用来查看当前一共创建了多少个对象
    // static 方法属于类，不需要新建对象，直接用类名.方法名() 就能调用
    public static void showCount() {
        System.out.println("当前一共创建了 " + count + " 个 Person 对象。");
    }
}

