package Task2;

public class Main {
    public static void main(String[] args) {
        // 3.创建对象并赋值
        Person p1 = new Person("小明", 18, 1);
        System.out.println(p1.getInfo());

        Person p2 = new Person(p1);
        System.out.println(p2.getInfo());

        // 4.5.直接调用静态方法，看看一共创建了几个对象
        // 调用静态方法不用 p1.showCount()，而是用类名 Person.showCount()
        Person.showCount();
    }
}