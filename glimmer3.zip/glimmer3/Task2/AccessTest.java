package Task2;

public class AccessTest {
    // 用来测试：在“同一个包”下的其他类，能不能访问 Person 的属性
    public static void main(String[] args) {
        // 创建一个 Person 对象
        Person p1 = new Person("测试员", 20, 1);

        // 尝试 1：在当前类（同一个包）里，访问 Person 的 name 属性
       //阻拦后续运行，注释掉
        /* System.out.println(p1.name);*/
    }
}