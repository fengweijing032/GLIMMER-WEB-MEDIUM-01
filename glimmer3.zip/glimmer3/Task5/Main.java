package Task5;

public class Main {
    public static void main(String[] args) {
        BankAccount acc1 = new BankAccount("1001", "张三", 1000, "123456");
        BankAccount acc2 = new BankAccount("1002", "李四", 500, "654321");

        System.out.println(acc1.getAccountInfo()); // 只看账户信息，看不到密码
        System.out.println("余额：" + acc1.getBalance());

        acc1.deposit(200);             // 存款 200
        acc1.withdraw(100, "123456");  // 取款 100，密码正确
        acc1.withdraw(50, "000000");   // 取款 50，密码错误（会失败）

        acc1.transfer(acc2, 300, "123456"); // 转账 300 给李四
        System.out.println("李四余额：" + acc2.getBalance());
    }
}