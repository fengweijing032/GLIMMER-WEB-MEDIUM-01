package Task5;

public class BankAccount {
    // 【要求3：余额,这里是属性，不能被外部随意修改，所以用 private 保护】
    private String accountNumber;
    private String accountHolder;
    private double balance;   // 余额，外部不能直接改
    private String password;  // 密码，外部也不能直接看

    // 初始化账户信息，这里以及后面都是方法，外人也要能使用，创建对象等，一般public
    public BankAccount(String accountNumber, String accountHolder, double initialBalance, String password) {
        this.accountNumber = accountNumber;
        this.accountHolder = accountHolder;
        this.balance = initialBalance;
        this.password = password;
    }

    // 存款方法
    public void deposit(double amount) {
        // 【要求1：金额不能是负数或零】
        if (amount <= 0) {
            System.out.println("存款失败：金额必须大于 0！");
            return;
        }
        balance += amount;
        System.out.println("存款成功，当前余额：" + balance);
    }

    // 取款方法
    public boolean withdraw(double amount, String inputPassword) {
        // 【要求1：金额不能是负数或零】
        if (amount <= 0) {
            System.out.println("取款失败：金额必须大于 0！");
            return false;
        }
        // 【要求2：取款前需要校验密码】
        if (!validatePassword(inputPassword)) {
            System.out.println("取款失败：密码错误！");
            return false;
        }
        // 检查余额是否充足
        if (amount > balance) {
            System.out.println("取款失败：余额不足！");
            return false;
        }
        balance -= amount;
        System.out.println("取款成功，当前余额：" + balance);
        return true;
    }

    // 转账方法，boolean检查干成了是否
    public boolean transfer(BankAccount recipient, double amount, String inputPassword) {
        // 【要求1：金额不能是负数或零】
        if (amount <= 0) {
            System.out.println("转账失败：金额必须大于 0！");
            return false;
        }
        // 【要求2：转账前需要校验密码】
        if (!validatePassword(inputPassword)) {
            System.out.println("转账失败：密码错误！");
            return false;
        }
        // 检查余额是否充足
        if (amount > balance) {
            System.out.println("转账失败：余额不足！");
            return false;
        }
        // 从自己的账户扣钱，给对方账户加钱
        this.balance -= amount;
        recipient.balance += amount;
        System.out.println("转账成功，当前余额：" + this.balance);
        return true;
    }

    // 查询余额（只暴露余额数值，不暴露密码等敏感信息）
    public double getBalance() {
        return balance;//只return保证不报错（double须有return），交出但先不打印
    }

    // 【要求4：敏感信息不应完整暴露，所以只返回账户号和户主名，隐藏密码】
    public String getAccountInfo() {
        return "账户号：" + accountNumber + "，户主：" + accountHolder;
    }

    // 校验密码（这里也是密码，但仅内部使用，是一个后台判断过程，所以用 private）
    private boolean validatePassword(String inputPassword) {
        return this.password.equals(inputPassword);
    }

    // 校验金额（仅内部使用，所以用 private）
    private boolean validateAmount(double amount) {
        return amount > 0;
    }
}