package Task4_2;

public interface Shape {
    // 接口里只声明方法，不写具体实现
    double getArea();
    double getPerimeter();
}