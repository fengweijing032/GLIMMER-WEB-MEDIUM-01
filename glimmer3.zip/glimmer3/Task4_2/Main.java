package Task4_2;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Shape> shapes = new ArrayList<>();
        shapes.add(new Circle(5));
        shapes.add(new Rectangle(4, 5));
        shapes.add(new Triangle(3, 4, 5));

        for (Shape shape : shapes) {
            System.out.println("图形的面积：" + shape.getArea());
            System.out.println("图形的周长：" + shape.getPerimeter());
            System.out.println("---");
        }
    }
}