package Task3;

public class Animal {
    // 用 protected 修饰，这样子类可以直接访问
    protected String name;
    protected int id;

    public Animal(String myName, int myId) {
        name = myName;
        id = myId;
    }

    public void eat() {
        System.out.println(name + "正在吃");
    }

    public void sleep() {
        System.out.println(name + "正在睡");
    }

    public void introduction() {
        System.out.println("大家好！我是" + id + "号" + name + "。");
    }
}