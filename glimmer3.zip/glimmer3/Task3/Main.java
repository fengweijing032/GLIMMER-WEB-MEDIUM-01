package Task3;

public class Main {
    public static void main(String[] args) {
        // 创建企鹅对象
        Penguin penguin = new Penguin("小企鹅", 1);
        penguin.eat();          // 调用从父类继承的 eat 方法
        penguin.introduction(); // 调用子类重写后的 introduction 方法

        System.out.println("---");

        // 创建老鼠对象
        Mouse mouse = new Mouse("小老鼠", 2);
        mouse.eat();
        mouse.introduction();
    }
}