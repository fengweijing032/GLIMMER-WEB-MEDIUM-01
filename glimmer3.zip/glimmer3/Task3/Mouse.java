package Task3;

public class Mouse extends Animal {

    public Mouse(String myName, int myId) {
        super(myName, myId); // 调用父类构造方法，super即为调用父类
    }

    // 重写父类的 introduction 方法，override让电脑帮助检查是否有拼写错误并提醒，明确这是重写，避免编写出小错误是被认为是新方法
    @Override
    public void introduction() {
        System.out.println("大家好！我是" + id + "号" + name + "，我是一只老鼠，我会打洞！");
    }
}