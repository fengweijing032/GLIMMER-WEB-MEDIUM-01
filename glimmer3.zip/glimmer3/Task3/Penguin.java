package Task3;

public class Penguin extends Animal {

    public Penguin(String myName, int myId) {
        super(myName, myId); // 调用父类构造方法
    }

    // 重写父类的 introduction 方法，前半部分一样，后面是自加
    @Override
    public void introduction() {
        System.out.println("大家好！我是" + id + "号" + name + "，我是一只企鹅，我会游泳！");
    }
}