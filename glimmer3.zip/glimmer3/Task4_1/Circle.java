package Task4_1;

public class Circle extends Shape {
    private double radius;//半径

    public Circle(double radius) {
        this.radius = radius;
    }

    @Override
    public double getArea() { return Math.PI * radius * radius; }//调用数学工具箱的Π

    @Override
    public double getPerimeter() { return 2 * Math.PI * radius; }
}