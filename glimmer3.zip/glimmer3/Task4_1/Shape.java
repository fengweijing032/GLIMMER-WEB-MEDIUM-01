package Task4_1;

public abstract class Shape {
    //计算面积，具体算怎么交给子类
    public abstract double getArea();
    //计算周长，具体怎么算交给子类
    public abstract double getPerimeter();
}
