package Task4_1;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // 把多种图形放进同一个集合里
        List<Shape> shapes = new ArrayList<>();
        shapes.add(new Circle(5));
        shapes.add(new Rectangle(4, 5));
        shapes.add(new Triangle(3, 4, 5));

        // 循环调用它们的方法（统一的调用方式）
        for (Shape shape : shapes) {
            System.out.println("图形的面积：" + shape.getArea());
            System.out.println("图形的周长：" + shape.getPerimeter());
            System.out.println("---");
        }
    }
}