package Task4_1;
//三角形
public class Triangle extends Shape {
    private double a, b, c;

    public Triangle(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    @Override
    public double getArea() {
        // 海伦公式求面积
        double p = (a + b + c) / 2;
        return Math.sqrt(p * (p - a) * (p - b) * (p - c));//sqrt开方
    }

    @Override
    public double getPerimeter() { return a + b + c; }
}