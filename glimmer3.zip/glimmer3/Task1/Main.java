package Task1;

public class Main {
    public static void main(String[] args){
        //在main创建至少一个Person对象，并给对象赋值
        Person p1 = new Person("小明", 18, 1);
        System.out.println("p1的信息:" + p1.getInfo());
        //使用刚才的方法，把p1复制一份给p2
        Person p2 = new Person(p1);
        System.out.println("p2的信息（复制自p1）：" + p2.getInfo());

    }
}
