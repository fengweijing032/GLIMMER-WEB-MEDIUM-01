package Task1;
import Task2.Person;//跨包导入

public class OtherTest {
    public static void main(String[] args){
        Person p1 = new Person("xiaoming", 18, 1);
       //阻拦后续运行，注释掉
        /* System.out.println(p1.name);*/
    }

}
