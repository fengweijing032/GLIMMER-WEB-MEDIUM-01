package  Task1;

public  class Person {
    private String name;//可装多个名字
    private int age;
    private int sex;

    //要求1，添加构造方法，实现复制对象的效果
    //初始化数据
    public Person(String name, int age, int sex) {
        //this指名当前正在创建的对象，参数名和属性名，用this.name告诉电脑左边的是属性（是名字），右边的是传入的参数（数字）
        this.name = name;
        this.age = age;
        this.sex = sex;
    }

    public Person(Person other) {
        //把传入对象的属性复制到当前新创建对象（this）
        this.name = other.name;
        this.age = other.age;
        this.sex = other.sex;
        //other.为旧
    }


    public String getInfo() {
        return "姓名：" + name + ", 年龄：" + age + ",性别：" + sex;
    }
}