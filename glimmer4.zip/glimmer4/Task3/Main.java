package Task3;

public class Main {
    public static void main(String[] args) {
        //  通过工厂分别创建 Saber、Archer、Caster 三个角色
        Character saber = CharacterFactory.createCharacter(CharacterType.SABER);
        Character archer = CharacterFactory.createCharacter(CharacterType.ARCHER);
        Character caster = CharacterFactory.createCharacter(CharacterType.CASTER);

        //  让每个角色发动攻击（调用 attack）
        saber.attack();
        archer.attack();
        caster.attack();
    }
}