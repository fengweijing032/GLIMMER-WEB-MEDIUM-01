package Task3;

// 列出角色类型
public enum CharacterType {
    SABER, ARCHER, CASTER
}