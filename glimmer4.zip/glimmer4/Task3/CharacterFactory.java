package Task3;

// 角色工厂
public class CharacterFactory {

    // 根据角色类型，返回对应的角色对象
    public static Character createCharacter(CharacterType type) {
        // 用 switch 判断传入的类型，转向不同分支
        switch (type) {
            case SABER:
                return new Saber(); // 如果是剑士，就造一个剑士
            case ARCHER:
                return new Archer(); // 如果是弓兵，就造一个弓兵
            case CASTER:
                return new Caster(); // 如果是法师，就造一个法师
            default:
                // 如果传入了未知的类型，抛出异常
                throw new IllegalArgumentException("未知的角色类型：" + type);
        }
    }
}