package Task3;

// 角色接口
public interface Character {
    // 定义 attack 方法
    void attack();
}