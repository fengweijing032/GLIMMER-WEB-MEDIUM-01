package Task1;

import java.util.ArrayList;
import java.util.List;

public class ListDemo_2 {
    public static void main(String[] args) {
        List<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);

        // 使用Lambda遍历
        list.forEach(num -> System.out.println(num));
    }
}