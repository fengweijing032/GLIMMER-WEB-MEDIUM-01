package Task2;

public class Main {
    public static void main(String[] args) {
        // 1. 存 String 类型
        //创建仓库
        MyRepository<String> stringRepo = new MyRepository<>();
        //存内容
        stringRepo.save("Hello");
        stringRepo.save("World");
        //分别根据id取出并打印
        System.out.println("String 仓库：");
        System.out.println(stringRepo.getById(0));
        System.out.println(stringRepo.getById(1));

        // 2. 存 User 类型
        MyRepository<User> userRepo = new MyRepository<>();
        userRepo.save(new User("张三", 18));
        userRepo.save(new User("李四", 20));
        System.out.println("User 仓库：");
        System.out.println(userRepo.getById(0));
        System.out.println(userRepo.getById(1));

        // 3. 存 Integer 类型
        MyRepository<Integer> intRepo = new MyRepository<>();
        intRepo.save(100);
        intRepo.save(200);
        System.out.println("Integer 仓库：");
        System.out.println(intRepo.getById(0));
        System.out.println(intRepo.getById(1));
    }
}