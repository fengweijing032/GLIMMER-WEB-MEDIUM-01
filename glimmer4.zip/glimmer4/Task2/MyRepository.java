package Task2;

import java.util.HashMap;
import java.util.Map;

public class MyRepository<T> implements Repository<T> { // 泛型 <T>，实现 Repository 接口

    // 用 HashMap 来存数据，key(键) 是 id，value（值）是数据
    private Map<Integer, T> storage = new HashMap<>();
    // 记录当前的 id，从 0 开始
    private int currentId = 0;

    @Override
    public void save(T data) {
        // 把数据存进 map，id 用 currentId，存完后 id 自增，这个过程实际是在给数据编号
        storage.put(currentId, data);
        currentId++;
    }

    @Override
    public T getById(int id) {
        // 根据 id 从 map 里取出数据
        return storage.get(id);
    }
}