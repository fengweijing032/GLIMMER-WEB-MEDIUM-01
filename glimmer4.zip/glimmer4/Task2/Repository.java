package Task2;

public interface Repository<T> { // <T> 就是泛型，表示这个仓库能存任意类型
    void save(T data); // 保存数据的方法，参数是泛型 T
    T getById(int id); // 根据 id 取出数据，返回值也是泛型 T
}