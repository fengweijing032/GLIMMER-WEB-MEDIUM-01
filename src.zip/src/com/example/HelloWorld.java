package com.example;
import com.example.tool.Print;

public class HelloWorld {
    public static void main(String[] args) {
        Print printObj = new Print();
        printObj.sayHello();
    }
}


