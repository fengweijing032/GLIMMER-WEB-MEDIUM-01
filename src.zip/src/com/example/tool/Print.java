package com.example.tool;

public class Print {
    public void sayHello(){
            System.out.println("Hello World");

    }

}
