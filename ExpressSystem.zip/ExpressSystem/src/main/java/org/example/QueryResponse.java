package org.example;

public class QueryResponse {
    //取件码
    private String pickCode;
    //提示信息（比如 "success" 或 "手机号不正确"）
    private String msg;

    //get和set方法
    public String getPickCode() { return pickCode; }
    public void setPickCode(String pickCode) { this.pickCode = pickCode; }
    public String getMsg() { return msg; }
    public void setMsg(String msg) { this.msg = msg; }
}