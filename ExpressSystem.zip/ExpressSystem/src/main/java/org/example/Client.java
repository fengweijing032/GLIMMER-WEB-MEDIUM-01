package org.example;

import com.alibaba.fastjson2.JSON;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Client {
    // 服务端地址
    private static final String SERVER_URL = "http://localhost:8000/query";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            try {
                // 读取用户输入的快递单号
                System.out.print("请输入快递单号（输入 exit 退出）：");
                String trackingNumber = scanner.nextLine().trim();

                // TODO 1：输入 exit 时退出循环
                if ("exit".equalsIgnoreCase(trackingNumber)) {
                    break;
                }

                // 读取用户输入手机号
                System.out.print("请输入手机号：");
                String phone = scanner.nextLine().trim();

                // TODO 2：用 fastjson 构造 JSON 格式的请求体
                QueryRequest request = new QueryRequest();
                request.setTrackingNumber(trackingNumber);
                request.setPhone(phone);
                String requestJson = JSON.toJSONString(request);

                // TODO 3：创建 HttpURLConnection，发送 POST 请求
                //URL指明地址，openConnection()打通联系
                URL url = new URL(SERVER_URL);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                //告诉对方，要提交数据，用post
                connection.setRequestMethod("POST");
                //告诉对方用json格式看
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setDoOutput(true);
                //准备说
                OutputStream os = connection.getOutputStream();
                //把信息说出
                os.write(requestJson.getBytes(StandardCharsets.UTF_8));
                //结束
                os.close();

                // 读取响应，状态码是 200 才是响应成功
                if (connection.getResponseCode() == 200) {
                    // TODO 4：读取响应体并解析 JSON，拿到取件码就打印取件码，拿不到就打印 msg 的内容
                    String responseJson = readBody(connection.getInputStream());
                    QueryResponse response = JSON.parseObject(responseJson, QueryResponse.class);
                    if (response.getPickCode() != null) {
                        System.out.println("取件码：" + response.getPickCode());
                    } else {
                        System.out.println("查询失败：" + response.getMsg());
                    }
                } else {
                    System.out.println("查询失败，状态码：" + connection.getResponseCode());
                }
                connection.disconnect();
            } catch (IOException e) {
                // 请求发生错误（比如 server 没启动），打印错误信息后继续循环
                System.out.println("请求发生错误：" + e.getMessage());
            }
        }
        scanner.close();
        System.out.println("客户端已退出");
    }

    /** 读取响应体：把 InputStream 按 UTF-8 读成一个字符串 */
    private static String readBody(InputStream is) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
        }
        return sb.toString();
    }
}