package org.example;

public class QueryRequest {
    //快递单号
    private String trackingNumber;
    //手机号
    private String phone;

    //get和set方法
    public String getTrackingNumber() { return trackingNumber; }
    public void setTrackingNumber(String trackingNumber) { this.trackingNumber = trackingNumber; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
}