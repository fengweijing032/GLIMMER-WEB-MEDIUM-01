package org.example;

import com.alibaba.fastjson2.JSON;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class Server {
    // 服务端监听端口
    private static final int PORT = 8000;
    // 模拟快递柜输入输出数据：key是快递单号_手机号，value为取件码
    private static final Map<String, String> expressMap = new HashMap<>();

    public static void main(String[] args) throws IOException {
        // 初始化测试数据
        initializeExpressData();
        //  HttpServer是JDK自带工具，创建能接受 HTTP 服务器，开一家快递公司，InetSocketAddres(PORT)明确端口，0是系统参数，不用管
        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
        // 服务窗口，要查询来/query，QueryHandler())是接待查询的工作人员
        server.createContext("/query", new QueryHandler());
        // 启动服务器
        server.start();
        System.out.println("Server started on port " + PORT);
    }

    // 初始化快递柜数据
    private static void initializeExpressData() {
        //登记对应信息
        expressMap.put("SF123456789_13005433678", "1234");
        expressMap.put("JD987654321_19805433168", "5678");
        expressMap.put("YT456789123_13905479698", "9012");
        expressMap.put("ZT789123456_18505433664", "3456");
    }

    // 处理 /query 请求的内部类，每一个的详细执行操作
    static class QueryHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            // 非 POST 请求返回 405 Method Not Allowed
            if (!"POST".equals(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(405, -1);
                exchange.close();
                return;
            }

            try {
                // 读取请求体（请求体是字节流，按 UTF-8 转成字符串），即（）里分别接收客户信息，按字节读取，以UTF_8翻译成文字
                String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
                // 解析 JSON 请求，json变java，取出单号和手机号
                QueryRequest request = JSON.parseObject(body, QueryRequest.class);
                String trackingNumber = request.getTrackingNumber();
                String phone = request.getPhone();

                // TODO 2：校验单号和手机号不能为空，不合法就抛异常走 400 分支
                if (trackingNumber == null || trackingNumber.isEmpty() ||
                        phone == null || phone.isEmpty()) {
                    throw new IllegalArgumentException("单号或手机号不能为空");
                }

                // TODO 3：用"单号_手机号"拼成 key，在 expressMap 中查询取件码
                String key = trackingNumber + "_" + phone;
                String pickCode = expressMap.get(key);

                // TODO 4：根据查询结果构造 QueryResponse
                QueryResponse response = new QueryResponse();
                if (pickCode != null) {
                    response.setPickCode(pickCode);
                    response.setMsg("success");
                } else {
                    response.setPickCode(null);
                    response.setMsg("手机号不正确或单号不存在");
                }

                // TODO 5：把响应对象序列化成 JSON 并发送响应（状态码 200）
                //查到结果变json
                String responseJson = JSON.toJSONString(response);
                //认定成功并告知长度
                exchange.sendResponseHeaders(200, responseJson.getBytes(StandardCharsets.UTF_8).length);
                OutputStream os = exchange.getResponseBody();
                os.write(responseJson.getBytes(StandardCharsets.UTF_8));
                os.close();

            } catch (Exception e) {
                // TODO 6：返回状态码 400 和错误 JSON
                String errorJson = "{\"pick_code\":null,\"msg\":\"请求格式错误\"}";
                exchange.sendResponseHeaders(400, errorJson.getBytes(StandardCharsets.UTF_8).length);
                OutputStream os = exchange.getResponseBody();
                os.write(errorJson.getBytes(StandardCharsets.UTF_8));
                os.close();
            }
        }
    }
}