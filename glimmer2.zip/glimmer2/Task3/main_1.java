package Task3;

import java.io.BufferedReader;  //读取文本文件
import java.io.FileNotFoundException;  //用来处理文件找不到的异常
import java.io.FileReader;   //打开文件
import java.io.IOException;  //处理其他输入输出错误

public class main_1 {

    public static void main(String[] args) {
        // 调用下面的方法，把计算逻辑拆分出去，不要全塞在 main 里
        calculateAverage();
    }

    public static void calculateAverage() {

        // 这里用了 try-with-resources 语法，把创建文件流写在 try 后面的括号里
        // 这样写的好处是：不管 try 里面的代码有没有报错，Java 都会自动帮我们在最后调用 close() 关掉文件
        // 彻底避免了“忘关文件导致资源泄漏”的问题
        try (BufferedReader br = new BufferedReader(new FileReader("data.txt"))) {

            String line;
            int sum = 0;       // 总和
            int count = 0;     // 有效数字的个数
            int lineNumber = 0; // 记录当前读到了第几行

            // 循环读取文件，每次读一行，读到 空 说明文件读完了
            while ((line = br.readLine()) != null) {
                lineNumber++;  //把空行计入，打印结果更精准
                line = line.trim(); // 去掉这一行首尾可能存在的空格，防止转数字时出错

                // 如果这行是空行，直接跳过，不计算
                if (line.isEmpty()) {
                    continue;
                }

                // 用一个内层的 try-catch 专门处理“格式转换错误”
                // 如果这一行不是数字（比如是 abc），程序不会整个崩溃，而是会执行 catch 里的提示，然后继续读下一行
                try {
                    int num = Integer.parseInt(line); // 把txt文本字符串转成可算整数
                    sum += num;
                    count++;
                } catch (NumberFormatException e) {
                    System.out.println("警告：第 " + lineNumber + " 行内容 '" + line + "' 不是合法的整数，已跳过。");
                } //数字转换失败
            }

            // 如果读完了整个文件，一个有效数字都没有（count为0），说明文件是空的
            // 这时候抛出我们自定义的异常 EmptyFileException，交给下面的 catch 处理
            if (count == 0) {
                throw new EmptyFileException("错误：文件为空！或者文件中没有有效的整数。");
            }

            // 计算平均值。注意这里要把 sum 60 强制转换成 double 60.0，否则整数相除会丢掉小数部分
            double average = (double) sum / count;
            System.out.println("文件读取成功！");
            System.out.println("有效整数个数：" + count);
            System.out.println("总和：" + sum);
            System.out.println("平均值：" + average);

        } catch (FileNotFoundException e) {
            // 如果连文件都找不到，就会走这个 catch
            System.out.println("错误：找不到 data.txt 文件，" +
                    "请确认它是否在项目根目录下！");
        } catch (EmptyFileException e) {
            // 专门用来接住上面自己抛出来的“文件为空”异常
            System.out.println(e.getMessage());
        } catch (IOException e) {
            // 捕获其他所有的输入输出错误（比如硬盘突然坏了）
            System.out.println("读取文件时发生错误：" + e.getMessage());
        }
    }
}