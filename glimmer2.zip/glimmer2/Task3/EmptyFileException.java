package Task3;

// 继承 Exception，做成一个受检异常
public class EmptyFileException extends Exception {
    public EmptyFileException(String message) {
        super(message);
    }
}
