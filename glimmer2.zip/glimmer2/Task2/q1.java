package Task2;

public class q1 {

    // 1. 判断闰年的函数
    public static boolean isLeapYear(int year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }

    // 2. 主函数（程序的入口）
    public static void main(String[] args) {
        int[] testYears = {2023, 2024, 1900, 2000};

        for (int year : testYears) {
            if (isLeapYear(year)) {
                System.out.println(year + " 是闰年");
            } else {
                System.out.println(year + " 不是闰年");
            }
        }
    }
}