package Task2;

public class q2 {

    public static void print(int n) {
        int mid = n / 2; // 中间行

        // --- 上半部分 ---
        for (int i = 0; i <= mid; i++) {
            // 1. 打印左边的空格
            for (int j = 0; j < mid - i; j++) {
                System.out.print(" ");
            }
            // 2. 打印第一个星星
            System.out.print("*");
            
            // 3. 如果不是第一行，打印中间空格和第二个星星
            if (i > 0) {
                for (int j = 0; j < 2 * i - 1; j++) {
                    System.out.print(" ");
                }
                System.out.print("*");
            }
            System.out.println(); // 换行
        }

        // --- 下半部分（倒着来）---
        for (int i = mid - 1; i >= 0; i--) {
            // 1. 打印左边的空格
            for (int j = 0; j < mid - i; j++) {
                System.out.print(" ");
            }
            // 2. 打印第一个星星
            System.out.print("*");
            
            // 3. 如果不是第一行，打印中间空格和第二个星星
            if (i > 0) {
                for (int j = 0; j < 2 * i - 1; j++) {
                    System.out.print(" ");
                }
                System.out.print("*");
            }
            System.out.println(); // 换行
        }
    }

    // 程序的入口
    public static void main(String[] args) {
        // 测试 n=5 的情况
        print(5);
    }
}