package Task2;

public class q3_2 {

    // 迭代法求斐波那契数列
    public static int fibonacciIterative(int n) {
        if (n == 1 || n == 2) {
            return 1;
        }
        int a = 1;
        int b = 1;
        int result = 0;
        for (int i = 3; i <= n; i++) {
            result = a + b;
            a = b;
            b = result;
        }
        return result;
    }

    // 程序的入口
    public static void main(String[] args) {
        int n = 10; // 测试第10个数
        System.out.println("迭代法求第 " + n + " 个斐波那契数是: " + fibonacciIterative(n));
    }
}
