package Task2;
public class q3_3 {

    // 汉诺塔递归函数
    // n: 盘子数，A: 起始柱，B: 辅助柱，C: 目标柱
    public static void hanoi(int n, char A, char B, char C) {
        if (n == 1) {
            // 只有一个盘子，直接从 A 移到 C
            System.out.println(A + " -> " + C);
        } else {
            // 第一步：把上面 n-1 个盘子，从A通过C移到B
            hanoi(n - 1, A, C, B);


            // 第二步：把最底下那个盘子，从 A 移到 C
            System.out.println(A + " -> " + C);

            // 第三步：把 B 上的 n-1 个盘子，从 B通过A 移到 C
            hanoi(n - 1, B, A, C);
        }
    }

    public static void main(String[] args) {
        // 测试 n=3 的情况
        System.out.println("n = 3 时，汉诺塔移动过程如下：");
        hanoi(3, 'A', 'B', 'C');
    }
}