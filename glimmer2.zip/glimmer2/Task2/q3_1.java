package Task2;

public class q3_1 {

    // 递归求斐波那契数列
    public static int fibonacciRecursive(int n) {
        if (n == 1 || n == 2) {
            return 1;
        }
        return fibonacciRecursive(n - 1) + fibonacciRecursive(n - 2);
    }


    public static void main(String[] args) {
        int n = 10; // 测试第 10 个数
        int result = fibonacciRecursive(n);
        System.out.println("递归法求第 " + n + " 个斐波那契数是: " + result);
    }
}