package Task4;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Main { //以上为“固定格式”，基本都有，只是填空不同

    public static void main(String[] args) {
        List<Student> students = Arrays.asList(//把零散数据（名字）打包成列表
                new Student("Alice", 85),
                new Student("Bob", 58),
                new Student("Charlie", 90),
                new Student("David", 45),
                new Student("Eve", 72),
                new Student("Frank", 60),
                new Student("Grace", 55),
                new Student("Heidi", 95)
        );


        List<String> passingStudents = students.stream()//把学生名字摆成流水线
                .filter(s -> s.getScore() >= 60)//按条件筛选元素
                .map(s -> s.getName().toUpperCase())//把元素变形
                .sorted()//把元素按规则排序
                .collect(Collectors.toList());//把处理完的元素收集

        System.out.println(passingStudents);
    }
}